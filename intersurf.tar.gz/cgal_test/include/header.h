/*-----------------------------------------------------------------------------
**  File:       hex_file.cpp
**
**  Author:     Dave Ritchie, xx/xx/11
**
**  Purpose:    The purpose.
**
**-----------------------------------------------------------------------------
**
**  Copyright (C) 2011 D.W. Ritchie, INRIA.
**
**  This software (or modified copies thereof) is protected by copyright and
**  may not be redistributed in any way without the express permission of the
**  author. Any questions about this copyright notice should be addressed to
**  dave.ritchie@inria.fr.
**
**  If this software was not obtained directly from Dave Ritchie, then it is
**  an unauthorised copy and it should be erased from your computer system,
**  and any associated media should be returned to the author.
**
**---------------------------------------------------------------------------*/

